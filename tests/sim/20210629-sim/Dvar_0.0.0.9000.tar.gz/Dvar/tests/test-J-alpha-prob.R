# Just to get started make an array J of all touples that will be included
I <- c(2, 3, 4)

J <- list()
J[[1]] <- 1
J[[2]] <- 2
J[[3]] <- 3
J[[4]] <- 4
J[[5]] <- 5
J[[6]] <- 6
J[[7]] <- c(2, 4)
J[[8]] <- c(2, 6)
J[[9]] <- c(3, 6)
J[[10]]<- c(1, 2, 3)


